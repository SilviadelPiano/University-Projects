# COLAB code for genes lists comparison

# you must mount again the drive each time you change the files that are stored there
from google.colab import drive
drive.mount('/content/drive')

# THIS IS THE ONLY PIECE OF CODE YOU NEED

# DISEASE GENES KEGG 1 ROW GENES LIST
kegg_row_genes_ds = open('path/file', 'r')
genes_ds_1 = kegg_row_genes_ds.readlines()

# print(len(genes_ds)) = 1 (just a single line with all genes divided by a white space)

genes_list_ds = genes_ds[0].split()
print(genes_list_ds[0])

#for i in range(len(genes_list_ds)):    #[correct, all genes are there]
#  print(genes_list_ds[i])

# DiaBLE PUTATIVE DISEASE GENES KEGG 1 ROW GENES LIST
kegg_row_genes_pds = open('path/file', 'r')
genes_pds = kegg_row_genes_pds.readlines()
genes_list_pds = genes_pds[0].split()
print(genes_list_pds[0])
#print(len(genes_list_ds))

# Compare lists [Format: PDS_row -> DS_row]
# 1 -> 1
common_genes_list = []
for i in range(len(genes_list_pds)):
  for j in range(len(genes_list_ds)):
    if genes_list_ds[j] == genes_list_pds[i]:
      common_genes_list.append(genes_list_pds[i])

print(common_genes_list)