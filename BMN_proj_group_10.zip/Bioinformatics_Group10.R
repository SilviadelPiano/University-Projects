##########################################################################
##                                                                      ##
##              Bioinformatics and Network Medicine: Project            ##
##                                Group 10                              ##
##             Silvia del Piano, Svenja Jedhoff, Marie Picquet          ##
##                                                                      ##
##########################################################################

# set directory
setwd("C:\\Users\\sjedh\\Desktop\\UNI\\Bioinformatics\\Project")

####################################
##          Loading Data          ##
####################################

## Node Analysis of Biogrid Data made by Cytoscape
node_ana <- read.table("analyses/BIOGRID_human_physical_clean_node_analysis.csv", 
                       sep = ",", header = TRUE)
table(node_ana$X__ccCluster)
#     1     2     3     4     5     6 
# 19711     1     1     1     1     1 
## the LCC contains 19711 nodes and 5 nodes are not connected


## Biogrid network, cleaned with cytoscape (no self-loops, only human and physical interactions)
network <- read.table("data/BIOGRID_human_physical_clean.csv", sep = ",",
                      header = TRUE)
## Get names of nodes
l <- strsplit(network$name, " ")
network$nodeA <- unlist(lapply(l, function(x) x[1]))
network$nodeB <- unlist(lapply(l, function(x) x[3]))

head(network, 3)
#   interaction                     name selected
# 1    physical CRYBA4 (physical) ZNF195    false
# 2    physical CRYBA4 (physical) GTF3C1    false
# 3    physical   CRYBA4 (physical) SBF1    false
#   shared.interaction              shared.name  nodeA  nodeB
# 1           physical CRYBA4 (physical) ZNF195 CRYBA4 ZNF195
# 2           physical CRYBA4 (physical) GTF3C1 CRYBA4 GTF3C1
# 3           physical   CRYBA4 (physical) SBF1 CRYBA4   SBF1


## Get disease/seed genes
disease_nodes <- read.table("data/Disease_nodes.txt")
disease_nodes <- disease_nodes[,1]

head(disease_nodes)
# [1] "ZNRD1"      "ZNF667-AS1" "ZNF593"     "ZNF559"    "ZNF382"     "ZNF177" 

## only 5 of the disease genes are not in the biogrid LCC
node_ana[node_ana$X__ccCluster != 1, "name"]
# "SLC24A2" "LRIT1"   "ELTD1"   "CLC"     "CYP11B2"


## Save the data for the diamond algorithm in the right format
write.csv(network[,c("nodeA","nodeB")], row.names = FALSE,
          "PPI_LCC.csv")


####################################
##    Statistics of Disease LCC   ##
####################################

## In this part of the code the main network metrices of the disease LCC genes,
## which were calculated with cytoscape are merged and prepared for the report.
## At the end a table with the metrics Ranking, Gene Name, Degree, Betweeness,
## Eigenvector Centrality, Closeness Centrality and the ratio between Betweeness
## and Degree is exported.

## node analysis of the LCC (from cytoscape)
LCC_stats <- read.csv("analyses/disease_gene_LCC_node_analysis.csv")
## eigenvalues from the nodes (computed with cytoscape)
LCC_eigen <- read.table("analyses/Disease_LCC_eigenvector.txt", skip = 3)
LCC_eigen <- LCC_eigen[,c(2,4)]
names(LCC_eigen) <- c("name", "Eigenvector Centrality")

## merging the two dataframes to get the eigenvalues in the same table with the rest
LCC_stats <- merge(LCC_stats, LCC_eigen, by = "name")

## Calculating ratio betweeness/degree
LCC_stats$ratio_betw_degree <- LCC_stats$BetweennessCentrality/LCC_stats$Degree

## Prepare table for report
LCC_stats_2 <- LCC_stats[,c("name", "Degree", "BetweennessCentrality",
                            "Eigenvector Centrality", "ClosenessCentrality",
                            "ratio_betw_degree")]

## order the data from decreasing ratio betweeness/degree
LCC_stats_orderd <- LCC_stats_2[order(LCC_stats_2$ratio_betw_degree, decreasing = TRUE),]

## round the data
LCC_stats_orderd$BetweennessCentrality <- round(LCC_stats_orderd$BetweennessCentrality, digits = 6)
LCC_stats_orderd$`Eigenvector Centrality` <- round(LCC_stats_orderd$`Eigenvector Centrality`, digits = 6)
LCC_stats_orderd$ClosenessCentrality <- round(LCC_stats_orderd$ClosenessCentrality, digits = 6)
LCC_stats_orderd$ratio_betw_degree <- round(LCC_stats_orderd$ratio_betw_degree, digits = 4)

## write the table to import in the report
write.table(LCC_stats_orderd[1:50,], "tab2.txt", sep = ",")



####################################
##       Cross Validation         ##
####################################

## In this part of the code the Cross Validation is performed. At the beginning,
## the disease Genes are splittet into 5 equal sized subsets and these subsets
## are exported as txt-files. After running the algorithm on the training sets 
## (diffusion in cytoscape, diamond and diable via python), the results are loaded
## into R and the precision, recall and F1-score are calculated in the next part
## of the code.

## Splitting the disease Genes into subsets for the Cross-Validation

## Remove genes that are not in the network:
disease_nodes_complete <- disease_nodes
length(disease_nodes_complete)
# 820 -> the data contains 820 disease genes
disease_nodes <- disease_nodes_complete[disease_nodes %in% network$nodeA |
                                        disease_nodes %in% network$nodeB]
length(disease_nodes)
# 784 -> only 784 of the disease genes are in the LCC

## Split the dataset in 5 equal large subsets
length(disease_nodes)/5 # -> 4 subsets with 156 genes, one with 157 genes
# 156.8

## Randomize the order of the disease nodes, so the constructed subsets are
## not in order of the daata
set.seed(13122022)
r <- sample(length(disease_nodes))
n <- length(disease_nodes)/5
## Partition the dataset: the test-sets contain each 1/5 of the disease genes
test_1 <- disease_nodes[r][(1*n-(n-1)):(1*n)]
test_2 <- disease_nodes[r][(2*n-(n-1)):(2*n)]
test_3 <- disease_nodes[r][(3*n-(n-1)):(3*n)]
test_4 <- disease_nodes[r][(4*n-(n-1)):(4*n)]
test_5 <- disease_nodes[r][c((5*n-(n-1)):(5*n),length(disease_nodes))]

## the corresponding train-sets contain the remaining 4/5 of the disease genes
train_1 <- c(test_2, test_3, test_4, test_5)
train_2 <- c(test_1, test_3, test_4, test_5)
train_3 <- c(test_1, test_2, test_4, test_5)
train_4 <- c(test_1, test_2, test_3, test_5)
train_5 <- c(test_1, test_2, test_3, test_4)

## save the data in seperate files
for(i in 1:5){
  name <- paste0("train_",i)
  write.table(mget(name),paste0("Diamond/data/",name, ".txt"),
              col.names = FALSE, row.names = FALSE, quote = FALSE)  
  name <- paste0("test_",i)
  write.table(mget(name),paste0("Diamond/data/",name, ".txt"),
              col.names = FALSE, row.names = FALSE, quote = FALSE)  
}



####################################
##    Performance Evaluation      ##
####################################

## In this part of the code the performance evaluation of the algorithm is calculated.
## Therefore, a function is implemented, where for each algorithm the correct 
## results are loaded and the metrices precision, recall and F1 score are calculated.
## The input argument of the function is the algorithm, which performance should
## be calculated. For each algorithm the performance are calculated for a different
## number of predicted disease genes X, where X = 50, 1/10 n, 1/4 n, 1/2 n, n;
## where n is the number of disease genes: n=784

## get all nodes of the LCC
all_nodes <- unique(c(network$nodeA, network$nodeB))

performance <- function(algorithm = c("diamond", "diable", "diffusion")){
  # in the rows: different test sets
  # in the columns: different X
  X <- round(c(50, 1/10 * n, 1/4 * n, 1/2 * n, n))

  ## Diffusion: the diffusion algorithm has an additional dimension, because
  ## three different values of t are tested
  if(algorithm == "diffusion"){
    ## arrays, where the corresponding results can be saved in
    precision <- array(NA, dim = c(5,5,3))
    dimnames(precision) <- list(1:5,X,t)
    recall <- array(NA, dim = c(5,5,3))
    dimnames(recall) <- list(1:5,X,t)
    F1 <- array(NA, dim = c(5,5,3))
    dimnames(F1) <- list(1:5,X,t)

    ## load the diffusion data
    load("diffusion.RData")
    ## little error in the rownames of the data made by human failure (me)
    names(diffusion)[1] <- sub("2","1",names(diffusion[1]),2,1)
    names(diffusion)[16] <- sub("2","1",names(diffusion[16]),2,1)
    ## the three different values of t that were tested
    t <- c("001","005", "01")
    
    ## for each value of t
    for(k in 1:3){
      
      ## get the right data from the dataset
      use <- names(diffusion)[grepl(t[k], names(diffusion)) & grepl("rank", names(diffusion))]
      data_algo <- diffusion[,c("name", use)]    
      
      # for each of the 5 CV-sets
      for(i in 1:5){
        
        ## Load the test-set
        test <- read.table(paste0("Diamond/data_train_test/test_",i, ".txt"))
        names(test) <- "name"
        data <- data.frame("name" = all_nodes, "true" = all_nodes %in% test$name)
        
        ## j for 1 in 5 : different number of X
        for(j in 1:5){
          ## get top X genes
          column <- paste0("diffusion_output_rank_",i,"_",t[k])
          topX <- data_algo[data_algo[column] <= X[j], "name"]
          ## Find values of the 2x2 contingency matrix:
          data[paste0("top",X[j])] <- all_nodes %in% topX
          tab <- table(data[c("true", paste0("top", X[j]))])
          ## Calculate the True Positive (tp), True Negative (tn), ...
          tp <- tab[2,2]
          tn <- tab[1,1]
          fn <- tab[2,1]
          fp <- tab[1,2]
          ## Calculate the metrices and save them in the right arrays
          precision[i,j,k] <- tp/(tp+fp)
          recall[i,j,k] <- tp/(tp+fn)
          F1[i,j,k] <- (2*tp)/(2*tp+fp+fn)  
        }  
      }
    }
    ## Calculate the mean and the sd over the five CV-sets for each t and X
    mean_precision <- apply(precision,c(2,3),mean)
    sd_precision <- apply(precision,c(2,3), sd)
    mean_recall <- apply(recall,c(2,3),mean)
    sd_recall <- apply(recall,c(2,3), sd)
    mean_F1 <- apply(F1,c(2,3),mean)
    sd_F1 <- apply(F1,c(2,3), sd)
    
    ## return the results
    return(list("precision_mean"=mean_precision, "precision_sd" = sd_precision,
    "recall_mean" = mean_recall, "recall_sd"=sd_recall, "F1_mean"=mean_F1,
    "F1_sd" = sd_F1))
  }
  
  
  ## If the algorithm is not diffusion: Diable or Diamond
  else{
    
    ## prepare matrices to save the results in
    precision <- matrix(NA, nrow = 5, ncol = 5)
    dimnames(precision) <- list(1:5, X)
    recall <- matrix(NA, nrow = 5, ncol = 5)
    dimnames(recall) <- list(1:5, X)
    F1 <- matrix(NA, nrow = 5, ncol = 5)
    dimnames(F1) <- list(1:5, X)
    
    
    # i for 1 in 5: for the five different CV-sets
    for(i in 1:5){
      ## number of diesase nodes
      n <- 784
      ## Load the diamond data
      if(algorithm == "diamond"){
        data_algo <- read.table(paste0("Diamond/diamond",i,".txt"))
        names(data_algo) <- c("rank", "name", "p")      
      }
      ## OR: Load the diable data
      if(algorithm == "diable"){
        data_algo <- read.table(paste0("Diamond/diable",i,".txt"))
        names(data_algo) <- c("rank", "name", "p")      
      }
      
      ## Load the corresponding test-set
      test <- read.table(paste0("Diamond/data_train_test/test_",i, ".txt"))
      names(test) <- "name"
      
      # merge it in one data frame
      data <- data.frame("name" = all_nodes, "true" = all_nodes %in% test$name)
      
      ## j for 1 in 5 : different number of X
      for(j in 1:5){
        ## get top X genes
        topX <- data_algo[1:X[j],"name"]
        ## Find values of the 2x2 contingency matrix:
        data[paste0("top",X[j])] <- all_nodes %in% topX
        tab <- table(data[c("true", paste0("top", X[j]))])
        ## Calculate the True Positive (tp), True Negative (tn), ...
        tp <- tab[2,2]
        tn <- tab[1,1]
        fn <- tab[2,1]
        fp <- tab[1,2]
        ## save the metrices in the corresponding matrices
        precision[i,j] <- tp/(tp+fp)
        recall[i,j] <- tp/(tp+fn)
        F1[i,j] <- (2*tp)/(2*tp+fp+fn)  
      }  
      
    }
  }
  
  ## calculate the mean and sd over the five CV-sets for each X
  mean_precision <- apply(precision, 2, mean)
  sd_precision <- apply(precision, 2, sd)
  mean_recall <- apply(recall, 2, mean)
  sd_recall <- apply(recall, 2, sd)
  mean_F1 <- apply(F1, 2, mean)
  sd_F1 <- apply(F1, 2, sd)
  
  ## return the results
  return(list("precision" = rbind(mean_precision, sd_precision), 
              "recall" = rbind(mean_recall, sd_recall), 
              "F1" = rbind(mean_F1, sd_F1)))
}

## diamond
diamond_performance <- performance("diamond")
diamond_performance
$precision
#                        50         78        196        392         784
# mean_precision 0.13200000 0.10256410 0.05918367 0.03877551 0.026785714
# sd_precision   0.07563068 0.05944627 0.02690087 0.01743301 0.009329553
# 
# $recall
#                     50         78        196        392        784
# mean_recall 0.04223420 0.05120039 0.07423649 0.09727258 0.13440307
# sd_recall   0.02418279 0.02967964 0.03370076 0.04366392 0.04670763
# 
# $F1
#                 50         78        196        392        784
# mean_F1 0.06399325 0.06830333 0.06586080 0.05544786 0.04466909
# sd_F1   0.03664737 0.03959194 0.02991903 0.02491737 0.01555246

## diable
diable_performance <- performance("diable")
diable_performance
# $precision
#                        50         78        196        392         784
# mean_precision 0.13200000 0.10256410 0.05918367 0.03877551 0.026785714
# sd_precision   0.07563068 0.05944627 0.02690087 0.01743301 0.009329553
# 
# $recall
#                     50         78        196        392        784
# mean_recall 0.04223420 0.05120039 0.07423649 0.09727258 0.13440307
# sd_recall   0.02418279 0.02967964 0.03370076 0.04366392 0.04670763
# 
# $F1
#                 50         78        196        392        784
# mean_F1 0.06399325 0.06830333 0.06586080 0.05544786 0.04466909
# sd_F1   0.03664737 0.03959194 0.02991903 0.02491737 0.01555246

## Diable and Diamond have the exact same results in the performance:
## the algorithms predict the extact same nodes



## diffusion
diffusion_performance <- performance("diffusion")
diffusion_performance
# $precision_mean
#           001         005         01
# 50  0.0000000 0.000000000 0.00000000
# 78  0.0000000 0.000000000 0.00000000
# 196 0.0000000 0.000000000 0.00000000
# 392 0.0000000 0.003053435 0.00000000
# 784 0.0155414 0.021401274 0.02191083
# 
# $precision_sd
#             001         005          01
# 50  0.000000000 0.000000000 0.000000000
# 78  0.000000000 0.000000000 0.000000000
# 196 0.000000000 0.000000000 0.000000000
# 392 0.000000000 0.004551792 0.000000000
# 784 0.002450367 0.005205813 0.005047545
# 
# $recall_mean
#            001         005        01
# 50  0.00000000 0.000000000 0.0000000
# 78  0.00000000 0.000000000 0.0000000
# 196 0.00000000 0.000000000 0.0000000
# 392 0.00000000 0.007692308 0.0000000
# 784 0.07809081 0.107512657 0.1100686
# 
# $recall_sd
#            001        005         01
# 50  0.00000000 0.00000000 0.00000000
# 78  0.00000000 0.00000000 0.00000000
# 196 0.00000000 0.00000000 0.00000000
# 392 0.00000000 0.01146702 0.00000000
# 784 0.01219859 0.02591171 0.02505701
# 
# $F1_mean
#            001         005         01
# 50  0.00000000 0.000000000 0.00000000
# 78  0.00000000 0.000000000 0.00000000
# 196 0.00000000 0.000000000 0.00000000
# 392 0.00000000 0.004371585 0.00000000
# 784 0.02592354 0.035696767 0.03654648
# 
# $F1_sd
#             001         005          01
# 50  0.000000000 0.000000000 0.000000000
# 78  0.000000000 0.000000000 0.000000000
# 196 0.000000000 0.000000000 0.000000000
# 392 0.000000000 0.006516774 0.000000000
# 784 0.004080914 0.008669799 0.008402535


## Why are so many values of the diffusion algorithm zero?
## the perfomance metrices have all the number of true positives in the
## numerator. Since there are no true positives, the value of the metrices
## are zero for all the 5 CV-sets and therefore the standard-devation is
## zero as well, since there is no variation

## Save the results, so it is not necessary to run the algorithm again
save(diamond_performance, diable_performance, diffusion_performance,
     file = "performance.RData")


########################################
## Perfomance: Graphical Visualizaion ##
########################################

## Load the package and the data
library(ggplot2)
library(dplyr)
load("performance.RData")


## To use ggplot, the data has to be in a better format:
dia <- data.frame("N" = c(50,78,196,392,784), 
           "measure" = rep(c("precision","recall", "F1"), each = 5),
           "mean" = c(diamond_performance$precision[1,],
                      diamond_performance$recall[1,],
                      diamond_performance$F1[1,]), 
           "sd" = c(diamond_performance$precision[2,],
                    diamond_performance$recall[2,],
                    diamond_performance$F1[2,]
                    ))
diab <- data.frame("N" = c(50,78,196,392,784), 
                   "measure" = rep(c("precision","recall", "F1"), each = 5),
                   "mean" = c(diable_performance$precision[1,],
                              diable_performance$recall[1,],
                              diable_performance$F1[1,]), 
                   "sd" = c(diable_performance$precision[2,],
                            diable_performance$recall[2,],
                            diable_performance$F1[2,]
                   ))

diff <- data.frame("N" = rep(c(50,78,196,392,784),each = 3),
                   "measure" = rep(c("precision","recall", "F1"),each = 15),
                   "mean" = c(diffusion_performance$precision_mean[1,],
                              diffusion_performance$precision_mean[2,],
                              diffusion_performance$precision_mean[3,],
                              diffusion_performance$precision_mean[4,],
                              diffusion_performance$precision_mean[5,],
                              diffusion_performance$recall_mean[1,],
                              diffusion_performance$recall_mean[2,],
                              diffusion_performance$recall_mean[3,],
                              diffusion_performance$recall_mean[4,],
                              diffusion_performance$recall_mean[5,],
                              diffusion_performance$F1_mean[1,],
                              diffusion_performance$F1_mean[2,],
                              diffusion_performance$F1_mean[3,],
                              diffusion_performance$F1_mean[4,],
                              diffusion_performance$F1_mean[5,]),
                   "sd" = c(diffusion_performance$precision_sd[1,],
                          diffusion_performance$precision_sd[2,],
                          diffusion_performance$precision_sd[3,],
                          diffusion_performance$precision_sd[4,],
                          diffusion_performance$precision_sd[5,],
                          diffusion_performance$recall_sd[1,],
                          diffusion_performance$recall_sd[2,],
                          diffusion_performance$recall_sd[3,],
                          diffusion_performance$recall_sd[4,],
                          diffusion_performance$recall_sd[5,],
                          diffusion_performance$F1_sd[1,],
                          diffusion_performance$F1_sd[2,],
                          diffusion_performance$F1_sd[3,],
                          diffusion_performance$F1_sd[4,],
                          diffusion_performance$F1_sd[5,]),
                   "t" = rep(c(0.001,0.005,0.01),15))

## Diamond
ggplot(data = dia, aes(x = N, y = mean)) +
  geom_point() +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd)) +
  facet_grid(cols = vars(measure)) +
  ylab("value")

## Diable: the same as diamond
ggplot(data = diab, aes(x = N, y = mean)) +
  geom_point() +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd)) +
  facet_grid(cols = vars(measure)) +
  ylab("value")

## Diffusion
svg("performance_diffusion.svg", height = 5)
ggplot(data = diff, aes(x = N, y = mean)) +
  geom_point() +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd )) +
  facet_grid(cols = vars(measure), rows = vars(t)) +
  ylab("value")
dev.off()

## Merging the data
all_algos <- rbind(cbind(dia, "t" = 0, "Algorithm" = "Diamond"),
                   cbind(diab, "t" = 0, "Algorithm" = "Diable"),
                   cbind(diff, "Algorithm" = "Diffusion"))
all_algos$t <- as.factor(all_algos$t)
all_algos$measure <- factor(all_algos$measure, labels = c("F1-Score", "Precision", "Recall"))

#pdf("diable_diamond_cv.pdf")
all_algos %>%
  filter(Algorithm != "Diamond", t %in% c(0,0.005)) %>%
  ggplot(aes(x = N, y = mean, col = Algorithm)) +
  geom_point() +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd)) +
  facet_grid(cols = vars(measure)) +
  ylab("value")
#dev.off()
# legende diamond/diffusion

jpeg("performance_graph.jpeg")
svg("performance_graph.svg", height = 5)
all_algos %>%
  filter(Algorithm != "Diamond", t %in% c(0,0.005)) %>%
  ggplot(aes(x = N, y = mean, col = Algorithm)) +
  geom_point() +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd)) +
  facet_grid(cols = vars(measure)) +
  labs(title = "Peformance Measures", y = "value") +
  scale_color_manual(labels = c("Diamond/Diable", "Diffusion (t=0.005)"), values = c("blue", "red"))
dev.off()


####################################
##      Drug Repurpsosing         ##
####################################

## In this part of the code the drug repurposing is done. Therefore, the data 
## from DGIdb is loaded and compared to the putative disease genes, which are
## computed by the diable algorithm

## Load the drug-gene-interaction-data
drugs <- read.table("drug_repurposing/interactions.tsv", sep = "\t", header = TRUE,
                    fill = TRUE)
## Load the results of the diable algo calculated on all the data
diable_all <- read.table("Diamond/diable_all.txt")
names(diable_all) <- c("rank", "gene", "p_value")

## Top 20 genes of the diable
top20 <- diable_all$gene[1:20]
table(top20 %in% drugs$gene_name) # only 14 of the top 20 genes are in the drug data
top20[! top20 %in% drugs$gene_name]

## Get the top 20 genes, that are in the drug-gene-interaction-datasets
top30 <- diable_all$gene[1:30]
top30 %in% drugs$gene_name
top20_new <- top30[top30 %in% drugs$gene_name][1:20]

## Get all the drugs that are associated with the 20 genes
drugs_genes <- numeric(0)
for(i in 1:20){
  drugs_genes <- c(drugs_genes, drugs[drugs$gene_name == top20_new[i],"drug_claim_name"])
}
drugs_data <- as.data.frame(table(drugs_genes))
head(drugs_data[order(drugs_data$Freq, decreasing = TRUE),])
#      drugs_genes Freq
# 388  SELUMETINIB    5
# 413 TANESPIMYCIN    5
# 426   TRAMETINIB    5
# 223     GDC-0973    4
# 371 RETASPIMYCIN    4
# 94       AT13387    3


####################################
##     Putative Disease Genes     ##
####################################

## Code for the comparison of putative disease genes and whole network

node_ana$ratio <- node_ana$BetweennessCentrality/node_ana$Degree

## Degree, Betweeness, Closeness, ratio Betw/Closeness
mean_all <- c(mean(node_ana$Degree), mean(node_ana$BetweennessCentrality), 
              mean(node_ana$ClosenessCentrality),
              mean(node_ana$ratio, na.rm = TRUE))
mean_putative <- apply(node_ana[node_ana$name %in% putative$V2, 
               c("Degree", "BetweennessCentrality",
                 "ClosenessCentrality", "ratio")],2, mean)
round(rbind(mean_all, mean_putative), digits = 6)
